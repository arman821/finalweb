<?php
// Initialize the session
session_start();
 
// Check if the user is already logged in, if yes then redirect him to welcome page
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header("location: dashboard.php");
    exit;
}
 
// Include config file
require_once "config.php";
 
// Define variables and initialize with empty values
$username = $password = "";
$username_err = $password_err = $login_err = "";
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
 
    // Check if username is empty
    if(empty(trim($_POST["username"]))){
        $username_err = "Please enter username.";
    } else{
        $username = trim($_POST["username"]);
    }
    
    // Check if password is empty
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter your password.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate credentials
    if(empty($username_err) && empty($password_err)){
        // Prepare a select statement
        $sql = "SELECT id, username, password FROM users WHERE username = ?";
        
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = $username;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["username"] = $username;                            
                            
                            // Redirect user to welcome page
                            header("location: dashboard.php");
                        } else{
                            // Password is not valid, display a generic error message
                            $login_err =  "Invalid username or password.";
                        }
                    }
                } else{
                    // Username doesn't exist, display a generic error message
                    $login_err = "Invalid username or password.";
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
    // Close connection
    mysqli_close($link);
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Login</title>
        <!-- Bootstrap core CSS -->
        <link rel="icon" href="images/favicon.png"/>
        <link href="https://fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i" rel="stylesheet">    
        <!-- Custom styles for this template -->
        <link href="css/style.css" rel="stylesheet">
         <script src="https://apis.google.com/js/platform.js" async defer></script>
     <meta name="google-signin-client_id" content="688644463538-nairps9lrnltoufskla52l8rsgln5evl.apps.googleusercontent.com">
<style>
   
      
      
  /*
Template Name: simple-plain-login
File Name: style.css
Author Name: ThemeVault
Author URI: http://www.themevault.net/
Licence URI: http://www.themevault.net/license/
*/

html {
    margin: 0;
    padding: 0;
}
body {
    font-family: 'PT Sans', sans-serif !important;
    margin: 0;
    padding: 40px 0;
    font-size:100%;
    letter-spacing: 1px; 
  background-color: #1e3953;
}
textarea:focus, input:focus, select:focus, select:active{
    outline: none;
    box-shadow:none;
}
.form-control:focus {
    box-shadow: none;
    outline: 0 none;
}
a{
    text-decoration: none;
}
.btn.active.focus, .btn.active:focus, .btn.focus, .btn.focus:active, .btn:active:focus, .btn:focus {outline: none;}
a,h1,h3,h4,h5{cursor: pointer;}
a:focus, a:hover{text-decoration: none;}
a:focus {outline: none; outline-offset: 0;}
ul{list-style: none;}
.placeholder-fix:focus::-webkit-input-placeholder  {color:transparent !important; }
.placeholder-fix:focus::-moz-placeholder   {color:transparent !important;}
.placeholder-fix:-moz-placeholder   {color:transparent !important;}
.logo h2 {
    font-size: 24px;
    letter-spacing: 3px;
    text-transform: uppercase;
    font-weight: 900;
    padding-bottom:40px;
      border-radius:50px;
    color:fff;
}
.content{
    background-color:#1e3953;
    text-align: center;
      border-radius:50px;
}
.login-page {
    background-color: #fff;
    box-shadow: 0 0 20px 10px rgba(38, 50, 56, 0.08);
    margin: 0 auto;
    width:460px;   
      border-radius:50px;
}
.login-page h3 {
    background-color: #88bb39;
    color: #fff;
    font-size: 22px;
    font-weight: 600;
    letter-spacing: 1px;
    margin: 0;
    padding: 30px;
    margin:center;
    
    text-align: left;
    text-transform: capitalize;
      border-radius:50px;
}
.login-page .form-control {
    background-color: #f0eef0 !important;
    background-image: none;
    border: 1px solid #88bb39;
    border-radius: 5px;
    color: #1e3953;
    display: block;
    font-size: 14px;
    height: 35px;
    letter-spacing: 1px;
    margin: 0 auto 15px;
    padding: 6px 10px;
    width: 300px;
    font-weight: 600;
      border-radius:50px;
}
.action-button button{
    width:300px;
    margin: 0 auto;
      border-radius:50px;
}
button {
    background: rgb(136, 187, 57) none repeat scroll 0 0;
    border: medium none;
    border-radius: 5px;
    color: #fff;
    font-size: 16px;
    font-weight: 600;
    margin-right: 10px;
    padding: 8px 20px;
      border-radius:50px;
}
.input-value input:first-child{
    background: url(../images/user.png);
    background-repeat: no-repeat;
    background-position: right center;
    background-origin: content-box;
      border-radius:50px;
}

.input-value input:last-child{
    background: url(../images/psw.png);
    background-repeat: no-repeat;
    background-position: right center;
    background-origin: content-box;
      border-radius:50px;
}
form {
    padding: 50px 0 20px;
    border-radius:50px;
}
.form-control::-moz-placeholder {
    color: #1e3953;
    font-weight: 600;
    opacity: 1;
}
.form-control::-webkit-input-placeholder{
    color: #1e3953;
    font-weight: 600;
    opacity: 1;
}
.input-value {
    padding: 0px 0 10px;
}
.page-links {
    padding: 0;
    text-align: center;
    padding: 20px 0;
}
.page-links li{
    display: inline-block;
}
.page-links a {
    color: rgb(30,57,83);
    font-size: 16px;
    font-weight: 600;
} 
.social-icon{
    margin: 50px 0;
}
.social-icon a{
    margin-right: 5px;      
}
.copyright {
    color: #fff;
    font-size: 16px;
}
.copyright a, .copyright a:hover{
    color:#88bb39;
    text-decoration: none;
}

/*media query*/
@media (max-width: 700px){
    .login-page .form-control {
        font-size: 13px;
        height: 30px;
        width: 250px;
    }
    .login-page {
        width: 400px;
    }
    .login-page h3 {
        font-size: 25px;
        padding: 20px;
        border-radius:50px;
    }
    .action-button button {
        margin: 0 auto;
        width: 250px;
    }
    form {
        padding: 30px 0 1px;
    }
    .logo h2 {
        padding-bottom: 20px;
        color:White;
    }
    .social-icon {
        margin: 40px 0;
    }
    button{
        font-size: 15px;
    }
    .page-links a {
        font-size: 14px;
    }
    .page-links {
        padding: 10px 0;
    }
}
@media (max-width: 370px){
    .login-page {
        width: 280px;
    }
    .login-page .form-control {
        font-size: 12px;
        height: 25px;
        width: 200px;
        margin: 0 auto 10px;
    }
    .action-button button {
        margin: 0 auto;
        width: 200px;
    }
    .page-links a {
        font-size: 13px;
    }
    button {
        font-size: 14px;
        padding: 8px;
    }
    .page-links {
    padding: 0;
}
h2{
    color:white;
}


.btn-block button {
    background: rgb(136, 187, 57) none repeat scroll 0 0;
    border: medium none;
    border-radius: 5px;
    color: #fff;
    font-size: 16px;
    font-weight: 600;
    margin-right: 10px;
    padding: 8px 20px;
}
    
</style>
    </head>
    <body class="content">
        <header>
            <div class="logo text-center">
               <img src="https://arman.gq/wp-content/uploads/2020/02/iconfinder_icon-1-cloud_316014-42x42.png" width="100" height="100"  />
            </div>
        </header>
        <section id="login-page">
            <div class="row">
                <div class="login-page text-center">
                    <h3 class="tagline">Login Form</h3>
                    <form  action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                <span class="invalid-feedback"><?php echo $username_err; ?></span>
            </div>    
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
                <span class="invalid-feedback"><?php echo $password_err; ?></span>
            </div>
            <div class="form-group">
                <button  class="btn-block" type="submit">Login</button>
            </div>
            <p>Don't have an account? <a href="registration.php">Sign up now</a>.</p>
           
        </form>
                </div>
                
                 <div class="copyright-box">
                    <div class="copyright">
                        <!--Do not remove Backlink from footer of the template. To remove it you can purchase the Backlink !-->
                        &copy; <a href="http://www.arman.gq/" target="_blank"><strong>Arman.</strong></a>
                    </div>
                </div>
            </div>
        </section>
    </body>
</html>
<script>
    function myFunction() {
  alert("Welcome to the javaTpoint.com");  
}
  
    
</script>